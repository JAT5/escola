package com.example.escola;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    private Button btnLogin;
    private EditText editLogin;
    private EditText editPass;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnLogin    = findViewById(R.id.btnLogin);
        editLogin   = findViewById(R.id.editLogin);
        editPass    = findViewById(R.id.editPass);

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String login    = editLogin.getText().toString();
                String pass     = editPass.getText().toString();
                if( login == "admin" && pass == "lgadminjat" ){

                    Intent it = new Intent(MainActivity.this, contentActivity.class);
                    startActivity(it);

                } else {

                    editLogin.setText("user/senha errado");

                }
            }
        });

    }


}
