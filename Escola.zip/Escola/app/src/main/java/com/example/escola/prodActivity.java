package com.example.escola;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.escola.models.product;

public class prodActivity extends AppCompatActivity {

    private EditText editProd;
    private EditText editLabel;
    private EditText editUnity;
    private EditText editBarCode;
    private Button btnSave;

    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_content);

        editProd    = findViewById(R.id.editProd);
        editLabel   = findViewById(R.id.editLabel);
        editUnity   = findViewById(R.id.editUnity);
        editBarCode = findViewById(R.id.editBarCode);
        btnSave     = findViewById(R.id.btnSave);

        mainContent();
    }

    public void mainContent(){

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String prodName     = editProd.getText().toString();
                String prodLabel    = editLabel.getText().toString();
                String prodUnity    = editUnity.getText().toString();
                String prodBarCode  = editBarCode.getText().toString();

                if( TextUtils.isEmpty( prodName ) && TextUtils.isEmpty( prodLabel ) && TextUtils.isEmpty( prodUnity ) && TextUtils.isEmpty( prodBarCode ) ){

                    //error message

                } else {

                    //call product object handler
                    product produto = new product( prodName, prodLabel, prodBarCode, prodUnity );

                }

            }
        });

    }

}
