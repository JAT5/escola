package com.example.escola.models;

import java.math.BigDecimal;

public class entry {

    private Integer idScool;

    private Integer idProvider;

    private Integer idProduct;

    private String prodUnity;

    private BigDecimal prodQuantity;

    private String entryObs;

    private String prodExpiration;

    public entry() {
    }

    public entry( Integer idScool, Integer idProvider, Integer idProduct, String prodUnity, BigDecimal prodQuantity, String entryObs, String prodExpiration ) {
        this.idScool        = idScool;
        this.idProvider     = idProvider;
        this.idProduct      = idProduct;
        this.prodUnity      = prodUnity;
        this.prodQuantity   = prodQuantity;
        this.entryObs       = entryObs;
        this.prodExpiration = prodExpiration;
    }

    public Integer getIdScool() {
        return idScool;
    }

    public void setIdScool(Integer idScool) {
        this.idScool = idScool;
    }

    public Integer getIdProvider() {
        return idProvider;
    }

    public void setIdProvider(Integer idProvider) {
        this.idProvider = idProvider;
    }

    public Integer getIdProduct() {
        return idProduct;
    }

    public void setIdProduct(Integer idProduct) {
        this.idProduct = idProduct;
    }

    public String getProdUnity() {
        return prodUnity;
    }

    public void setProdUnity(String prodUnity) {
        this.prodUnity = prodUnity;
    }

    public BigDecimal getProdQuantity() {
        return prodQuantity;
    }

    public void setProdQuantity(BigDecimal prodQuantity) {
        this.prodQuantity = prodQuantity;
    }

    public String getEntryObs() {
        return entryObs;
    }

    public void setEntryObs(String entryObs) {
        this.entryObs = entryObs;
    }

    public String getProdExpiration() {
        return prodExpiration;
    }

    public void setProdExpiration(String prodExpiration) {
        this.prodExpiration = prodExpiration;
    }

}