package com.example.escola.models;

public class product {

    private String prodName;

    private String prodLabel;

    private String barCode;

    private String prodUnity;

    public product() {
    }

    public product( String prodName, String prodLabel, String barCode, String prodUnity ) {
        this.prodName = prodName;
        this.prodLabel = prodLabel;
        this.barCode = barCode;
        this.prodUnity = prodUnity;
    }

    public String getprodName() {
        return prodName;
    }

    public void setprodName(String prodName) {
        this.prodName = prodName;
    }

    public String getprodLabel() {
        return prodLabel;
    }

    public void setprodLabel(String prodLabel) {
        this.prodLabel = prodLabel;
    }

    public String getbarCode() {
        return barCode;
    }

    public void setbarCode(String barCode) {
        this.barCode = barCode;
    }

    public String getprodUnity() {
        return prodUnity;
    }

    public void setprodUnity(String prodUnity) {
        this.prodUnity = prodUnity;
    }

}
