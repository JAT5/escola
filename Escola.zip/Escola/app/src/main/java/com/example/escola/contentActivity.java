package com.example.escola;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class contentActivity extends AppCompatActivity {

    private Button btnListProd;
    private Button btnInsertProd;
    private Button btnListProv;
    private Button btnInsertProv;
    private Button btnListEntry;
    private Button btnInsertEntry;

    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_content);

        mainContent();
    }

    public void mainContent(){

        btnInsertProd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent it = new Intent(contentActivity.this, prodActivity.class);
                startActivity(it);

            }
        });

        btnInsertEntry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent it = new Intent(contentActivity.this, entryActivity.class);
                startActivity(it);

            }
        });

    }

}
