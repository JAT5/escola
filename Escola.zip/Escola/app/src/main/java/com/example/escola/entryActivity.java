package com.example.escola;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.escola.models.entry;

import java.math.BigDecimal;

public class entryActivity extends AppCompatActivity {

    private EditText editProd;
    private EditText editObs;
    private EditText editQuantity;
    private EditText editUnity;
    private EditText editExpiration;
    private EditText editScool;
    private EditText editProv;
    private Button btnSave;

    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_content);

        editProd        = findViewById(R.id.editProd);
        editObs         = findViewById(R.id.editObs);
        editQuantity    = findViewById(R.id.editQuantity);
        editUnity       = findViewById(R.id.editUnity);
        editExpiration  = findViewById(R.id.editExpiration);
        editScool       = findViewById(R.id.editScool);
        editProv        = findViewById(R.id.editProv);
        btnSave         = findViewById(R.id.btnSave);

        mainContent();
    }

    public void mainContent(){

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Integer prodId          = Integer.parseInt( editProd.getText().toString() );
                String prodQuantity     = editQuantity.getText().toString().replaceAll("[$,.]", "");
                BigDecimal prodQnt      = new BigDecimal(prodQuantity).setScale(2, BigDecimal.ROUND_FLOOR).divide(new BigDecimal(100), BigDecimal.ROUND_FLOOR);
                String prodUnity        = editUnity.getText().toString();
                String prodExpiration   = editExpiration.getText().toString();
                Integer entryScoolId    = Integer.parseInt( editScool.getText().toString() );
                Integer prodProv        = Integer.parseInt( editProv.getText().toString() );
                String entryObs         = editObs.getText().toString();

                if( prodId != null && prodId.intValue() > 0 && prodQnt != null && prodQnt.intValue() > 0 && TextUtils.isEmpty( prodUnity ) &&
                        TextUtils.isEmpty( prodExpiration ) && entryScoolId != null && entryScoolId.intValue() > 0 && prodProv != null && prodProv.intValue() > 0 ){

                    //error message

                } else {

                    //call entry object handler
                    entry entrada = new entry( prodId, prodProv, prodId, prodUnity, prodQnt, entryObs, prodExpiration );

                }

            }
        });

    }
}
